#!/bin/sh
sed 's/$/\r/' $@
