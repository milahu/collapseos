5 LOAD   \ z80 assembler
360 LOAD \ TRS-80 4P decl
370 LOAD \ TRS-80 4P bootloader
