: (emit) 0 PC! ;
236 239 LOADR ( forth high )
XWRAP" BLK$ ' EFS@ ' BLK@* **! ' EFS! ' BLK!* **! "
