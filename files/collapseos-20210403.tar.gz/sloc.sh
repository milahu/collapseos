#!/bin/sh
grep -v \\-\\-\\-\\-\\- blk.fs | wc -l
