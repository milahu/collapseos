42 C, 43 C, 44 C,
H@ 3 - H@ 3 MOVE
H@ C@ 42 #eq H@ 1+ C@ 43 #eq H@ 2+ C@ 44 #eq
H@ H@ 1+ 3 MOVE ( demonstrate MOVE's problem )
H@ 1+ C@ 42 #eq H@ 2+ C@ 42 #eq H@ 3 + C@ 42 #eq
H@ 3 - H@ 3 MOVE
H@ H@ 1+ 3 MOVE- ( see? better )
H@ 1+ C@ 42 #eq H@ 2+ C@ 43 #eq H@ 3 + C@ 44 #eq

H@ ( ref )
H@ 3 - 3 MOVE,
( ref ) H@ 3 - #eq
H@ 3 - C@ 42 #eq H@ 2- C@ 43 #eq H@ 1- C@ 44 #eq
