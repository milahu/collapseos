50 LOAD ( 6809 assembler )
HERE ORG !
470 LOAD ( boot.6809 )
ORG @ |M 2 PC! 2 PC!
HERE |M 2 PC! 2 PC!
