#!/bin/sh
echo -e "50 LOAD HERE ORG !\n$(cat -)\nORG @ 256 /MOD 2 PC! 2 PC! HERE 256 /MOD 2 PC! 2 PC! " | ./stage
