#!/bin/sh
echo -e "5 LOAD\nHERE 256 /MOD 2 PC! 2 PC!\n$(cat -)\nHERE 256 /MOD 2 PC! 2 PC! " | ./stage
