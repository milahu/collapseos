612 LOAD ( PC/AT xcomp )
ORG @ |M 2 PC! 2 PC!
HERE |M 2 PC! 2 PC!
