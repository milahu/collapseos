\ TODO: verify that the produced binary is still working. I
\ haven't tested it in quite a while.
ARCHM XCOMP AVRA 0 XSTART
324 342 LOADR
