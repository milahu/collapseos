: (emit) 0 PC! ;
: INIT BLK$ ;
XWRAP
