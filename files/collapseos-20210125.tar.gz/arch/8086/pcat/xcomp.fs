612 LOAD ( PC/AT xcomp )
ORG @ |M 2 PC! 2 PC!
H@ |M 2 PC! 2 PC!
