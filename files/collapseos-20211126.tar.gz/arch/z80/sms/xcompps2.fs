\ TODO: verify that the produced binary is still working. I
\ haven't tested it in quite a while.
ARCHM AVRA
324 342 LOADR
