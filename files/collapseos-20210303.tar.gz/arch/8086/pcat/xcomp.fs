612 LOAD ( PC/AT xcomp )
