# Testing Collapse OS

This folder contains Collapse OS' automated testing suite. You can run all tests
with `make`.
