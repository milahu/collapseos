: (emit) 0 PC! ;
XWRAP INIT
