: (emit) 0 PC! ;
236 239 LOADR ( forth high )
XWRAP INIT
